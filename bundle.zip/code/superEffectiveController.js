
const typeTable = require('./typeTable.json');


function superEffective(type1, type2) {

    //check for null values


    //variables
    let weakTo = "text";
    

    
    //logic



    console.log(`${type1} and ${type2} is weak to ${weakTo}`);


}
console.log("type table working: " + typeTable.working);
superEffective("normal", "fighting");
console.log();